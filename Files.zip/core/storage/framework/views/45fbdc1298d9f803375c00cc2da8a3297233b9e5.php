<?php $__env->startSection('content'); ?>



    <div class="row">

        <div class="row">
            <div class="col-md-12">
                <h3 class="page_title"><?php echo $page_title; ?> </h3>
                <hr>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-sm-4 text-center">
                    <div class="panel panel-primary panel-pricing">
                        <div class="panel-heading">
                            <h3 style="font-size: 28px;"><b><?php echo e($p->name); ?></b></h3>
                        </div>
                        <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                            <img class="" style="width: 35%;border-radius: 5px" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($p->image); ?>" alt="">
                        </div>
                        <ul style='font-size: 15px;' class="list-group text-center bold">
                            <li class="list-group-item">Minimum - <?php echo $p->withdraw_min; ?> <?php echo e($basic->currency); ?> </li>
                            <li class="list-group-item">Maximum - <?php echo $p->withdraw_max; ?> <?php echo e($basic->currency); ?> </li>
                            <li class="list-group-item"> Charge - <?php echo e($p->fix); ?> + <?php echo e($p->percent); ?><i class="fa fa-percent"></i> <?php echo e($basic->currency); ?></li>
                            <li class="list-group-item">Processing Time - <?php echo $p->duration; ?> Days </li>
                        </ul>
                        <div class="panel-footer" style="overflow: hidden">
                            <div class="col-sm-12">
                                <a href="javascript:;" <?php if($basic->withdraw_status == 0): ?> disabled <?php else: ?> onclick="jQuery('#modal-<?php echo e($p->id); ?>').modal('show');" <?php endif; ?> class="btn btn-info btn-block btn-icon btn-lg bold icon-left"><i class="fa fa-cloud-upload"></i> Withdraw Now</a>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div><!-- ROW-->

    <?php $__currentLoopData = $method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="modal fade" id="modal-<?php echo e($b->id); ?>">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title"><i class="fa fa-cloud-upload"></i> <strong>Withdraw via <?php echo e($b->name); ?></strong> </h4>
                    </div>
                    <?php echo e(Form::open()); ?>

                    <input type="hidden" name="method_id" value="<?php echo e($b->id); ?>">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label style="font-size: 14px;margin-top: 30px;" class="col-sm-2 col-sm-offset-1 control-label"><strong>Amount : </strong></label>
                                    <div class="col-sm-9">
                                        <span style="margin-bottom: 10px;"><code>Withdraw Charge : (<?php echo e($b->fix); ?> + <?php echo e($b->percent); ?>%) - <?php echo e($basic->currency); ?></code></span>
                                        <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                            <input type="number" value="" id="amount" name="amount" class="form-control" required />
                                            <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="form-group">
                                    <div class="col-sm-9 col-sm-offset-3">
                                        <button class="btn btn-primary btn-block"><i class="fa fa-send"></i> Withdraw Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>