<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <table class="table table-striped table-bordered table-hover" id="sample_1">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Date Time</th>
            <th>Transaction ID</th>
            <th>Invest Plan</th>
            <th>Invest Amount</th>
            <th>Invest Commission</th>
            <th>Repeat Time</th>
            <th>Repeat Compound</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php $i = 0;?>
        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++;?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td width="10%"><?php echo e(date('d-F-Y h:s:i A',strtotime($p->created_at))); ?></td>
                <td>#<?php echo e($p->trx_id); ?></td>
                <td><span class="aaaa"><strong><?php echo e($p->plan->name); ?></strong></span></td>
                <td><?php echo e($p->amount); ?> - <?php echo e($basic->currency); ?></td>
                <td><?php echo e($p->plan->percent); ?> %</td>
                <td><?php echo e($p->plan->time); ?> - Times</td>
                <td><span class="aaaa"><strong><?php echo e($p->plan->compound->name); ?></strong></span></td>
                <td>
                    <?php if($p->status == 0): ?>
                        <span class="label label-warning bold uppercase"><i class="fa fa-spinner"></i> Running</span>
                    <?php else: ?>
                        <span class="label label-success bold uppercase"><i class="fa fa-check" aria-hidden="true"></i> Completed</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>