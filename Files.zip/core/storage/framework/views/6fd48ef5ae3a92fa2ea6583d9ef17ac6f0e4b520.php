<?php $__env->startSection('style'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">


            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-dark">
                    </div>
                    <div class="tools"> </div>
                </div>
                <div class="portlet-body" style="overflow: hidden">
                    <div class="row">
                    <div class="col-md-12">
                        <div class="text-center bold">
                            <h3>Transaction ID : #<?php echo e($deposit->transaction_id); ?></h3>
                            <h3>Deposit Method : <?php echo e($deposit->bank->name); ?></h3>
                            <h3>Send Amount : <?php echo e($deposit->net_amount * $deposit->bank->rate); ?> - <?php echo e($deposit->bank->currency); ?></h3>
                            <h3>Deposit Amount : <?php echo e($deposit->amount); ?> - <?php echo e($basic->currency); ?></h3>
							<h3>Depositor : <a href="<?php echo e(route('user-details',$deposit->user_id)); ?>" class="btn btn-primary"><i class="fa fa-user"></i> <?php echo e($deposit->member->username); ?></a></h3>
							<hr>
							<h3>Status : 

									<?php if($deposit->status == 1): ?>
                                        <span class="label label-primary bold uppercase"><i class="fa fa-check"></i> Approved</span>
                                    <?php elseif($deposit->status == 2): ?>
                                            <span class="label label-danger bold uppercase"><i class="fa fa-times"></i> Cancel</span>
                                     <?php elseif($deposit->status == 0): ?>
                                            <span class="label label-warning bold uppercase"><i class="fa fa-spinner"></i> Pending</span>
                                    <?php endif; ?>
							</h3>
                            <hr>
							<?php if($deposit->status == 0): ?>
                            <div class="col-md-3 col-md-offset-3">
                                <button type="button" class="btn btn-success bold uppercase btn-block delete_button"
                                        data-toggle="modal" data-target="#DelModal"
                                        data-id="<?php echo e($deposit->id); ?>">
                                    <i class='fa fa-check'></i> Approve Payment
                                </button>
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-danger bold uppercase btn-block cancel_button"
                                        data-toggle="modal" data-target="#cancelModal"
                                        data-id="<?php echo e($deposit->id); ?>">
                                    <i class='fa fa-times'></i> Cancel Payment
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <h3>Message : </h3><br>
                            <?php echo $deposit->message; ?>

                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <?php $img = \App\DepositImage::whereDeposit_id($deposit->id)->get() ?>
                            <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <a target="_blank" href="<?php echo e(asset('assets/deposit')); ?>/<?php echo e($im->image); ?>">
                                    <img src="<?php echo e(asset('assets/deposit')); ?>/<?php echo e($im->image); ?>" class="img-responsive" alt="">
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div><!-- ROW-->
    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title bold uppercase" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> <strong>Confirmation..!</strong></h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you Want to Approve This Deposit Request..?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('manual-deposit-approve')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Yes. I am Sure.</button>
                    </form>
                </div>

            </div>
        </div>
    </div>

    <div class="modal fade" id="cancelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title  bold uppercase" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> <strong>Confirmation..!</strong></h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you Want to Cancel This Deposit Request..?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('manual-deposit-cancel')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Yes. I am Sure.</button>
                    </form>
                </div>

            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
        $(document).ready(function () {

            $(document).on("click", '.cancel_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>