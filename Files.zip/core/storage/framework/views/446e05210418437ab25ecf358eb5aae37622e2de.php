<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

      <div class="portlet light bordered">
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-hover" id="depoist_request_table">

                        <thead>
                        <tr>
                            <th>ID#</th>
                            <th>Date</th>
                            <th>Transaction ID</th>
                            <th>User</th>
                            <th>Status</th>
                            <th>Amount</th>
                            <th style="text-align: center;">Action</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i=0;?>
                        <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++;?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e(date('d-F-Y h:i A',strtotime($p->created_at))); ?></td>
                                <td><?php echo e($p->custom); ?></td>
                                <td><?php echo e($p->user->username); ?></td>
                                <td>
                                    <?php if($p->status == 0): ?>
                                        <span class="label bold label-warning"><i class="fa fa-spinner"></i> Waiting</span>
                                    <?php elseif($p->status == 1): ?>
                                        <span class="label bold label-success"><i class="fa fa-check-square-o"></i> Complete</span>
                                    <?php elseif($p->status == 3): ?>
                                        <span class="label bold label-danger"><i class="fa fa-times"></i> Cancel</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($p->amount); ?> - <?php echo e($basic->currency); ?>

                                </td>
                                <td style="text-align: center;">
                                    <?php if($p->status == 0): ?>
                                    <div class="btn-group btn-group-sm btn-group-solid">

                                    <button type="button" class="btn btn-sm delete_button" style="border-radius: 0px; background-color: #5cb85c; color:#fff" value="<?php echo e($p->id); ?>" data-toggle="modal" href="#small" balance="<?php echo e($p->amount); ?>" status="1" user_id="<?php echo e($p->user->id); ?>">Approve</button>

                                     <button type="button" class="btn btn-sm red delete_button" style="border-radius: 0px" value="<?php echo e($p->id); ?>" data-toggle="modal" href="#small" status="2">Cancel </button> </div>
                                    <?php else: ?>

                                    <a href="javascript:;" class="btn default blue-stripe"> <b> Not Available </b></a>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo $log->links(); ?>

                    </div>
                </div>
            </div>

        </div>
    </div><!-- ROW-->


<!-- Modal Dialog -->
<div class="modal fade" id="small" role="dialog" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title"> <b class="text-uppercase"> <span id="modal-heading">Deposit Request Cancel</span> </b></h4>
      </div>
      <div class="modal-body">
        <h5> <b>Are you sure about this ?</b></h5>
      </div>
      <div class="modal-footer">
         <button type="button" class="btn btn-danger btn-block" data-dismiss="modal" id="confirm_delete" style="color:#fff">Yes</button>
      </div>
    </div>
  </div>
</div>
<input type="hidden" id="del_id">
<input type="hidden" id="balance">
<input type="hidden" id="status">
<input type="hidden" id="user_id">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>

 $(document).ready(function() {

        $(document).on('click','.delete_button',function(){
    
                $("#del_id").val($(this).val());
                $("#balance").val($(this).attr('balance'))
                $("#status").val($(this).attr('status'));
                $("#user_id").val($(this).attr('user_id'));
                
                if($(this).attr('status')==1){
                    $('#modal-heading').text('Deposit Request Approve');
                    $('#confirm_delete').removeClass('btn-danger');
                    $('#confirm_delete').addClass('btn-success');
                }else{
                   $('#modal-heading').text('Deposit Request Cancel');
                   $('#confirm_delete').removeClass('btn-success');
                   $('#confirm_delete').addClass('btn-danger');
                }
           
          });   
                 
        $(document).on('click','#confirm_delete',function(){
              
            var id = $("#del_id").val();
            var amount = $("#balance").val(); 
            var status = $("#status").val(); 
            var uesr_id =  $("#user_id").val();
            var href = window.location.href.concat(' #depoist_request_table') ;    
            $.get("<?php echo e(route('admin-payment-request-cancel')); ?>",{id,amount,status,uesr_id}, function(data){
              console.log(data);
                var href = window.location.href.concat(' #depoist_request_table') ;
                 $( "#depoist_request_table" ).load(href);
                 
                 if(status==1){
                    swal('Approve','Approve Successfully','success');
                 }else{
                    swal('Cancel','Cancel Successfully','error');
                 }
                 
            });  
        });
 });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>