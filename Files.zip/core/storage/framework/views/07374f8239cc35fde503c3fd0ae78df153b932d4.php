<section class="breadcrumb-section" style="background-image: url('<?php echo e(asset('assets/images/logo/bb.png')); ?>')">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <!-- breadcrumb Section Start -->
            <div class="breadcrumb-content">
              <h5><?php echo $page_title; ?></h5>
            </div>
            <!-- Breadcrumb section End -->
          </div>
        </div>
      </div>
    </section>