<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>" rel="stylesheet">

    <style>
        input[type="text"] {
            width: 100%;
        }

        input[type="email"] {
            wi
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content_padding">
    <div class="container user-dashboard-body">
        
    <div class="row">
        <div class="login-admin login-admin1">
            <div class="login-header text-center">
                <h6><?php echo $page_title; ?></h6>
            </div>
             <?php echo Form::open(['method'=>'post','role'=>'form','class'=>'form-horizontal','files'=>true]); ?>

            <div class="row">
                <div class="col-md-3">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" data-trigger="fileinput">
                                <img style="width: 200px" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($user->image); ?>" alt="...">
                            </div>
                            <div class="fileinput-preview fileinput-exists thumbnail" style="max-width: 200px; max-height: 150px"></div>
                            
                            <div class="img-input-div">
                                                <span class="btn btn-info btn-file">
                                                    <span class="fileinput-new bold uppercase"><i class="fa fa-file-image-o"></i> Select image</span>
                                                    <span class="fileinput-exists bold uppercase"><i class="fa fa-edit"></i> Change</span>
                                                    <input type="file" name="image" accept="image/*">
                                                </span>
                                <a href="#" class="btn btn-danger fileinput-exists bold uppercase" data-dismiss="fileinput"><i class="fa fa-trash"></i> Remove</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-9">
                     <div class="row">
                        <div class="col-md-6">
                                             <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">Name :</strong></label>
                                        <div class="col-md-12">
                                            <input type="text" name="name" id="" value="<?php echo e($user->name); ?>"  required placeholder="Name">
                                        </div>
                                    </div>
                        </div>
                        <div class="col-md-6">
                                            <div class="form-group">
                                        <label class="col-md-12"><strong style="text-transform: uppercase;">User Name :</strong></label>
                                        <div class="col-md-12">
                                            <input type="text" name="username" id="" value="<?php echo e($user->username); ?>" required placeholder="Username">
                                        </div>
                                    </div>
                        </div>

                        <div class="col-md-6">
                              <div class="form-group">
                                <label class="col-md-12"><strong style="text-transform: uppercase;">Email :</strong></label>
                                <div class="col-md-12">
                                    <input type="email" name="email" id="" value="<?php echo e($user->email); ?>" required placeholder="Email">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                             <div class="form-group">
                    <label class="col-md-12"><strong style="text-transform: uppercase;">Phone :</strong></label>
                    <div class="col-md-12">
                        <input type="text" name="phone" id="" value="<?php echo e($user->phone); ?>" required placeholder="Phone">
                    </div>
                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                                <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                        <button type="submit" class="new-btn-submit"><i class="fa fa-send"></i> UPDATE PROFILE</button>
                    </div>
                </div>
            </div>
            
        </div> 
    </div>
    <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>

    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('message')); ?>", "success");

            });

        </script>

    <?php endif; ?>

    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo session('alert'); ?>", "error");

            });

        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>